﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp18
{
    internal class Program
    {
        
    public  static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());

            if (isprime(number)) {
                Console.WriteLine("Is Prime number");

            }
            else {
                Console.WriteLine("Not prime number");
                    }
            Console.ReadLine();
        }
    public static bool isprime(int num)
        {
            int i;
            if (num <= 1)
            {
                return false;
            }
            for(i = 2; i <= Math.Sqrt(num); i++)
            {
                if(num % i == 0)
                {
                    return false;               }
            }
            
           return true;

            
        }
    }
}
