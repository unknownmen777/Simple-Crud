﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp25
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
            int num = Convert.ToInt32(Console.ReadLine());

            long factorial = fact(num);
            Console.WriteLine("factorial of {0} is {1}",num , factorial);
            Console.ReadLine();

        }

        public static long fact(int n)
        {
            long result = 1;
            if (n < 0)
            {
               Console.WriteLine("Please enter the positive  value");
            }
            if (n == 0 || n == 1)
            {
                return 1;
            }
            for (int i = 2; i <= n; i++)
            {
                result *= i;
            }
            return result;
        }
    }
}
