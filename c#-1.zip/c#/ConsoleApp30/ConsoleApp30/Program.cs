﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp30
{
    internal class Program
    {
        public static void main(String[] args)
        {
            Console.WriteLine("hello");
        Console.ReadLine();
        }
    }
}
