﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the color of fruit");
            string color = Console.ReadLine();

            switch (color)
            {
                case "green":
                    Console.WriteLine("guava");
                    break;

                case "yello":
                    Console.WriteLine("mango, banana");
                    break;
                case "red":
                    Console.WriteLine("Apple");
                    break;
                default:
                    Console.WriteLine("sorry not found");
                    break;
            }
            Console.ReadLine();
        }
    }
}
