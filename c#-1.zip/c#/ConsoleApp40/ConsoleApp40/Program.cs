﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp40
{

    class pet { 
     public void show()
        {
            Console.WriteLine("pet class");
        }
    }

    class dog : pet {

        public new void show()
        {
            Console.WriteLine("dog class");
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            dog dog = new dog();
            dog.show();
            Console.ReadKey();
        }
    }
}
