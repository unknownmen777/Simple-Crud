﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the first number ");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Second  number ");
            int b = int.Parse(Console.ReadLine());

            int sum = a + b;
            Console.WriteLine("Adition is {0}", sum);

            int sub = a - b;
            Console.WriteLine("Sub is {0}", sub);

            int mul = a * b;
            Console.WriteLine("MUl is {0}", mul);

            double div = (float)a / b;
            Console.WriteLine("Div is {0}", div);
            Console.ReadLine();
        }

    }
}
