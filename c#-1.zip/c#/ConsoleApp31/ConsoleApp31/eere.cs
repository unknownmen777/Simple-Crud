﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp31
{
    internal class eere
    {
        public static void main(String[] args)
        {
            Console.WriteLine("heloooooooooooooooooooooooooo");
        }
    }
}
