﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
            int num = Convert.ToInt32(Console.ReadLine());

            if (num % 7 == 0)
            {
                Console.WriteLine("{0} is divisible by 7 ", num);
            }
            else
            {
                Console.WriteLine("not divisible by 7");
            }
            Console.ReadLine();
        }
    }
}
