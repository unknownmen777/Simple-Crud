﻿using System;

namespace PassByReferenceExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 10;
            Console.WriteLine("Before method call: " + number); // Output: 10
            ModifyValue(ref number);
            Console.WriteLine("After method call: " + number);  // Output: 20
        }

        static void ModifyValue(ref int value)
        {
            value = 20;
        }
    }
}