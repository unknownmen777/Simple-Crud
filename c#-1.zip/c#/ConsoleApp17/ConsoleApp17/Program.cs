﻿using System;

namespace ConsoleApp17
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            int i;
            int sum = 0;
            for (i = 5; i <= 100; i++)
            {
                sum = sum + i;
            }
            Console.WriteLine("The sum of numbers from 5 to 100 is: " + sum);
            Console.ReadLine();
        }
    }
}
