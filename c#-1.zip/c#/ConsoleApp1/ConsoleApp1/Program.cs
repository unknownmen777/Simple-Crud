﻿using System;


namespace ConsoleApp1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter Your Name");
            string name = Console.ReadLine();
            Console.WriteLine(" yOUR Name  IS :{0} ", name);
            Console.ReadLine();
        }
    }
}
