﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp34
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr1 = new int[100];
            int[] arr2 = new int[100];
            int i, n;

            Console.WriteLine("Enter the sixze ");
            n =  Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the element ");
            for (i = 0; i < n; i++)
            {
                arr1[i] = Convert.ToInt32(Console.ReadLine());

             }

            for (i = 0; i < n; i++)
            {
                arr2[i] = arr1[i];

            }
            Console.WriteLine("Elements of array 1 ");
            for (i = 0; i < n; i++)
            {
                Console.WriteLine(arr1[i]);

            }

            Console.WriteLine("Elements of array 2 ");
            for (i = 0; i < n; i++)
            {
                Console.WriteLine(arr2[i]);

            }
            Console.ReadLine();
        }
    }
}
