﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp43
{
    public delegate void AreaOfCircle(float r);
    public delegate void AreaOfSquare(float s);
    internal class Program
    {
        public static void AOC(float r)
        {
            Console.WriteLine("Area of Circle is {0} ", Math.PI * Math.Pow(r,2));
        }
        public static void AOS(float s)
        {
            Console.WriteLine("Area of Square {0} ", Math.Pow(s,2) );
        }

        static void Main(string[] args)
        {
            AreaOfCircle aoc = new AreaOfCircle(AOC);
            aoc(2.8f);
            AreaOfSquare aos = new AreaOfSquare(AOS);
            aos(7.8f);
            Console.ReadLine();
        }
    }
}
