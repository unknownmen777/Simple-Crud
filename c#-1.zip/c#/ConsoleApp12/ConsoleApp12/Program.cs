﻿using System;

class Program
{
    static void Main()
    {
        // Input a number from the user
        Console.WriteLine("Enter a number:");
        int number = Convert.ToInt32(Console.ReadLine());

        // Check if the number is divisible by both 5 and 10
        if (number % 5 == 0 && number % 10 == 0)
        {
            Console.WriteLine("The number " + number + " is divisible by both 5 and 10.");
        }
        else
        {
            Console.WriteLine("The number " + number + " is not divisible by both 5 and 10.");
        }
        Console.ReadLine();
    }
}