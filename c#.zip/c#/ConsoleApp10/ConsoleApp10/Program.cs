﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int largest;
            int a = Convert.ToInt32(Console.ReadLine()); 
            int b = Convert.ToInt32(Console.ReadLine());
            int c = Convert.ToInt32(Console.ReadLine());

            if (a > b && a > c)
            {
                 largest = a;
            }
            else if (b > a && b > c)
            {
                 largest = b;
            }
            else
            {
                 largest = c;
            }
            Console.WriteLine("{0} is largest number", largest);
            Console.ReadLine();
        }
    }
}
