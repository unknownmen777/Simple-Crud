﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("eNTER THE NUMBER");
            int a = Convert.ToInt32(Console.ReadLine());
            if (a % 7 == 0 && a % 13 != 0) {
                Console.WriteLine("{0} is divisible 7 not 13", a);
            }
            else
            {
                Console.WriteLine("not divisible by 7 nor 13");
            }
            Console.ReadLine();
        }
    }
}
