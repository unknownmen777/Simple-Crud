﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp38
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] arr1 = new int[50, 50];
            int[,] arr2 = new int[50, 50];
            int[,] arrmul = new int[50, 50];
            int sum = 0;

            int i, j, k;

            Console.WriteLine("Enter the arr1 row size");
            int r1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the arr1 Column size ");
            int c1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the arr2 row size");
            int r2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the arr2 Column size ");
            int c2 = Convert.ToInt32(Console.ReadLine());

            if (r1 != c2)
            {
                Console.WriteLine("Not Possible.");
            }

            else
            {


                Console.WriteLine("Enter the element of arr1 ");
                for (i = 0; i < r1; i++)
                {
                    for (j = 0; j < c1; j++)
                    {
                        arr1[i, j] = Convert.ToInt32(Console.ReadLine());
                    }
                }

                Console.WriteLine("Enter the element of arr2 ");
                for (i = 0; i < r2; i++)
                {
                    for (j = 0; j < c2; j++)
                    {
                        arr2[i, j] = Convert.ToInt32(Console.ReadLine());
                    }
                }

                Console.Write("\nDisplay arr1 \n");
                for (i = 0; i < r1; i++)
                {
                    Console.Write("\n");
                    for (j = 0; j < c1; j++)
                    {
                        Console.Write(arr1[i, j] + "\t");
                    }
                }

                Console.Write("\nDisplay arr2 \n");
                for (i = 0; i < r2; i++)
                {
                    Console.Write("\n");
                    for (j = 0; j < c2; j++)
                    {
                        Console.Write(arr2[i, j] + "\t");
                    }
                }

                // multiplication process

                for (i = 0; i < r1; i++)
                {
                    for (j = 0; j < c2; j++)
                    {
                        for (k = 0; k < c1; k++)
                        {
                            sum += arr1[i, k] * arr2[k, j];
                            arrmul[i, j] = sum;
                        }
                    }
                }

                Console.Write("\nDisplay Multiplication of matrix\n");
                for (i = 0; i < r1; i++)
                {
                    Console.Write("\n");
                    for (j = 0; j < c1; j++)
                    {
                        Console.Write(arrmul[i, j] + "\t");
                    }
                }
            }
            Console.ReadLine();
        }
    }
}
