﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousFunction
{

    public delegate void mymethod(int num);

    
    internal class Program
    {
        static void Main(string[] args)
        {
            mymethod a = delegate (int num)
            {
                num += 10;
                Console.WriteLine(num);
            };
            a(5);
            Console.ReadLine();
        }
    }
}
