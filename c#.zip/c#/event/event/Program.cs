﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @event
{

    public delegate void AnonymouseMethod(int num);
    internal class Program
    {
        public static void MyMethod(AnonymouseMethod del , int num)
        {
            num += 10;
            del.Invoke(num);
        }
        static void Main(string[] args)
        {
            Program.MyMethod(delegate (int a) { a += 5; Console.WriteLine(a); },5);
            Console.ReadLine();
        }
    }
}
