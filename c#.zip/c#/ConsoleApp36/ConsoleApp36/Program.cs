﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp36
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr1 = new int[10];
            int[] arr2 = new int[10];
            int[] arr3 = new int[10];

            int n, i,j, count=1,c=0;
        
            n = int.Parse(Console.ReadLine());

            for (i = 0; i < n; i++)
            {
                arr1[i] = int.Parse(Console.ReadLine());
            }
            for (i = 0; i < n; i++)
            {
                arr2[i]=arr1[i];
                arr3[i] = 0;

            }

            for (i = 0; i < n; i++)
            {
                for (j = 0; j < n; j++)
                {
                    if (arr1[i] == arr2[j])
                    {
                        arr3[j] = count;
                        count++;
                    }
                }
                count = 1;
            }
            for (i = 0; i < n; i++)
            {
                if (arr3[i] == 2)
                {
                    c++;
                }
            }
            Console.WriteLine("Count is {0}", c);
            Console.ReadLine();
        }
    }
}
