﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp22
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the age");
            int age = Convert.ToInt32(Console.ReadLine());

            string vote = (age>=18) ? "you can vote " : "you cannot vote";
            Console.WriteLine(vote);
            Console.ReadLine();
        }
    }
}
