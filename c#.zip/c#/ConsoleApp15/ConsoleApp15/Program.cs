﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Cost Price ");
            int cp = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Selling Price");
            int sp =Convert.ToInt32(Console.ReadLine());

            if (cp > sp) {
            float loss = (float)cp - sp;
                Console.WriteLine("{0} is loss amount", loss);
            }
            if (sp > cp)
            {
                float profit = (float)sp - cp;
                Console.WriteLine("{0} is profit amount", profit);
            }
            else
            {
                Console.WriteLine("Nither loss nor profit");
            }
            Console.ReadLine();
        }
    }
}
