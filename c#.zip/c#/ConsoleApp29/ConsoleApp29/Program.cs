﻿using System;
using System.ComponentModel;

namespace ConsoleApp29
{
    class Program
    {
        //      Write a C# Sharp program that stores elements in an array and prints them
        static void Main(string[] args)
        { string confrim;
            do
            {
                int[] arr = new int[5]
                { 1,2,3,4,5};

                foreach (int i in arr)
                {
                    Console.WriteLine(i);
                }
                Console.WriteLine("yes/no");
                confrim = Console.ReadLine().ToLower();
            }
            while (confrim == "yes");
            }
    }
}