﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp34
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[100];
            int count = 0, i, sum = 0;

            String Confrim, restart;
            do
            {
                do
                {
                    Console.WriteLine("Do you want to enter  number Yes/No");
                    Confrim = Console.ReadLine().ToLower();

                    if (Confrim == "yes")
                    {
                        Console.WriteLine("Enter the number ");
                        int num = Convert.ToInt32(Console.ReadLine());

                        if (count < arr.Length)
                        {
                            arr[count] = num;
                            count++;
                        }
                        else
                        {
                            Console.WriteLine("Array is full");
                            break;
                        }

                    }
                    else if (Confrim != "no")
                    {
                        Console.WriteLine("Invalid Response!!!");

                    }
                }
                while (Confrim != "no");

                Console.WriteLine("\n\n");
                Console.WriteLine("Stored numbers:");
                for (i = 0; i < count; i++)
                {
                    Console.Write(arr[i] + " ");
                }
                Console.WriteLine();

                Console.WriteLine("\n\n");
                for (i = 0; i < count; i++)
                {
                    if (arr[i] % 2 != 0)
                    {
                        sum += arr[i];
                    }
                }
                Console.WriteLine("sum of odd number is : {0}", sum);
                Console.WriteLine("\n\n");
                Console.WriteLine("To Restart enter Yes or No ");
                restart = Console.ReadLine().ToLower();
            }
            while (restart != "no");
            
        }
    }
}
