﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiCastDelegate
{
    public delegate void Calculation(int a, int b);

    internal class Program
    {

        public static void addition(int a, int b)
        {
            Console.WriteLine("Adition is {0}", a + b);
        }
        public static void subraction(int a, int b)
        {
            Console.WriteLine("Subraction is {0}", a - b);
        }
        public static void multiplication(int a, int b)
        {
            Console.WriteLine("multiplication is {0}", a + b);
        }
        public static void division(int a, int b)
        {
            Console.WriteLine("Division is {0}", a / b);
        }
        static void Main(string[] args)
        {

            Calculation p = new Calculation(addition);
            p += subraction;
            p += multiplication;
            p += division;
            //p -= multiplication;
            p(20, 30);
            Console.ReadKey();
        }
    }
}
