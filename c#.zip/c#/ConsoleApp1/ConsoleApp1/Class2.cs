﻿using System;


namespace ConsoleApp1
{
    internal class Class2

    {
        public static void main(string[] args) {
            Console.WriteLine("Enter num 1 ");
           int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter num 2 ");
            int b = int.Parse(Console.ReadLine());

            if( a == b)
            {
                Console.WriteLine("{0} and {1} are equal ", a, b);
            }
            else
            {
                Console.WriteLine("Not Equal ");

            }
            Console.ReadLine();
        }
    }
}