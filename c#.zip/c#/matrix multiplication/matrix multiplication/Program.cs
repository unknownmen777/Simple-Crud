﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace matrix_multiplication
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i, n;  // Declaration of variables 'i' and 'n'
            int[] a = new int[100];  // Declaration of an integer array 'a' with size 100

            // Display a message about reading n number of values in an array and displaying it in reverse order
            Console.Write("\n\nRead n number of values in an array and display it in reverse order:\n");
            Console.Write("------------------------------------------------------------------------\n");

            Console.Write("Input the number of elements to store in the array: ");  // Prompt the user to input the number of elements
            n = Convert.ToInt32(Console.ReadLine());  // Read the number of elements from the user and store it in 'n'

            Console.Write("Input {0} number of elements in the array:\n", n);  // Prompt the user to input 'n' elements

            // Loop to read 'n' elements from the user and store them in the array 'a'
            for (i = 0; i < n; i++)
            {
                Console.Write("element - {0} : ", i);  // Prompt for input element number
                a[i] = Convert.ToInt32(Console.ReadLine());  // Read user input and store it in the array 'a'
            }

            Console.Write("\nThe values stored into the array are:\n");

            // Loop to display the elements stored in the array 'a'
            for (i = 0; i < n; i++)
            {
                Console.Write("{0}  ", a[i]);  // Display each element of the array 'a'
            }

            Console.Write("\n\nThe values stored into the array in reverse are:\n");

            // Loop to display the elements stored in the array 'a' in reverse order
            for (i = n - 1; i >= 0; i--)
            {
                Console.Write("{0} ", a[i]);  // Display each element of the array 'a' in reverse order
            }

            Console.Write("\n\n");  // Move to the next line for better readability
        }
    }
}
