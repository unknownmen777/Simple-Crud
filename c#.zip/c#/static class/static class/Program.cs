﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace static_class
{
static class product  { 


        public static int id ;
        public static string name;
        public static int  price ;
    
     static product()
    {
        id = 10;
        name = "computer";
        price = 50000;
    }

        public static void  productdetail()
        {
            Console.WriteLine("Product id = {0} ", id);
            Console.WriteLine("Product Name = {0} ", name);
            Console.WriteLine("Product Price = {0} ", price);
        }



    public static void  getdiscount()
    {
            float d_price = price / 10;
            Console.WriteLine("Discount = {0}", d_price);
            Console.WriteLine("Total Price = {0} ", (price - d_price));
        }
}

    internal class Program
    {
        static void Main(string[] args)
        {
            product.productdetail();
            product.getdiscount();
            Console.ReadKey();
        }
    }
}
