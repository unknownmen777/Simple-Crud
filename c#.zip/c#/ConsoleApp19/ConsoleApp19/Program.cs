﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i;
            for (i = 0; i <= 100; i++)
            {
                if (isprime(i))
                {
                    Console.WriteLine(i);
                }
            }
            Console.ReadLine();
        }
        public static bool isprime(int num) {
            if (num<=1) {
                return false; };
            for(int i = 2; i <= Math.Sqrt(num); i++)
            {
                if(num %i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
