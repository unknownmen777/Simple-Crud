﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp42
{

    sealed class person {
        public void show()
        {
            Console.WriteLine("cannot inherite");

        }
        class man : person {
        
            public void iamman()
            {
                Console.WriteLine("I Am Man ");
            }

        }

        internal class Program
    {
        static void Main(string[] args)
        {
        man m = new man();
                m.iamman();
        }
    }
}
