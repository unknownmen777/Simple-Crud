﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp32
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[10];
            int i, sum = 0;

            Console.WriteLine("Enter the array Length ");
            int n = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the elements");
            for (i = 0; i < n; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine("sum of array");

            for (i = 0; i < n; i++)
            {
                sum += arr[i];
            }
            Console.WriteLine(sum);
            Console.ReadLine();
        }
    }
}
