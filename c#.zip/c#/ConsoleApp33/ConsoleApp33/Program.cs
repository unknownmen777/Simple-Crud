﻿using System;

namespace ConsoleApp32;

internal class Program
{
    private static void Main(string[] args)
    {
        int[] arr = new int[100];
        int count = 0;
        do
        {
            Console.WriteLine("Do you want to enter  number Yes/No");
            string Confrim = Console.ReadLine().ToLower();
            if (Confrim == "yes")
            {
                Console.WriteLine("Enter the number ");
                int num = Convert.ToInt32(Console.ReadLine());

                if (count < arr.Length)
                {
                    arr[i] = num;
                    count++;
                }
                else
                {
                    Console.WriteLine("Array is full");
                    break;
                }
                Console.WriteLine("Stored array : {0}", arr[i]);


            else if (Confrim != "no")
                {
                    Console.WriteLine("Invalid Response!!!")

                }
            }
            while (Confrim != "no") ;
            Console.ReadLine();
        }

    }
}
