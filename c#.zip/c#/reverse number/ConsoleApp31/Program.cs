﻿using System;

namespace ConsoleApp31
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int rev = 0;
            Console.WriteLine("Enter the number ");
            int num = Convert.ToInt32(Console.ReadLine());

            while (num > 0)
            {
                int digit = num % 10;
                rev = rev * 10 + digit;
                num = num / 10;
            }

            Console.WriteLine("Reverse number is {0}", rev);
            Console.ReadLine();
        }
    }
}
