﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp16
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int i;

            for(i=1; i<=10; i++)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
