﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class person {

    string name;
    int age;
    public person(string name, int age)
    {
        this.name = name;
        this.age = age;
    }

    public person(person e)
    {
        this.name = e.name;
        this.age = e.age;
    }
    public void display()
    {
        Console.WriteLine("Nmae =  {0} ", name);
        Console.WriteLine("Age = {0} ", age);
    }
}


namespace copy_constructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            person obj = new person("adil", 23);
            obj.display();

            person obj2 = new person(obj);
            obj2.display();
            Console.ReadKey();
        }
    }
}
