﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp20
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the last number or range : ");
            int end = int.Parse(Console.ReadLine());
            for (int i = 0; i <= end; i++)
            {
                if (isprime(i))
                {
                    Console.WriteLine(i);
                }
            }
            Console.ReadLine();
        }

        public static bool isprime(int num)
        {
            if (num <= 1)
            {
                return false;
            }
            for (int i = 2; i <= Math.Sqrt(num); i++)
            {
                if (num % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
