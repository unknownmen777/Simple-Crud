﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace indexer
{

    class indexer {
    
    private int[] arr= new int[3];

        public int this[int a]
        {

            set { arr[a] = value; }
            get
            {
                return arr[a];
            }
        

        }


    }


    internal class Program
    {
        static void Main(string[] args)
        {

            indexer i = new indexer();
            i[2] = 3;
            i[1] = 4;
            i[2] = 5;
            Console.WriteLine(i[2]);
            Console.WriteLine(i[1]);
            //Console.WriteLine(i[0]);
            Console.ReadLine();

        }
    }
}
