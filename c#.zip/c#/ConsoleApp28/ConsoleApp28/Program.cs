﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp28
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String Confrim;
            do
            {
                Console.WriteLine("Enter the First Number ");
                int num1 = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the Second Number");
                int num2 = int.Parse(Console.ReadLine());
                Console.WriteLine("Do you restart? Yes/No");
                Confrim = Console.ReadLine().ToLower();
            }
            while (Confrim == "yes");

        }
    }
}
