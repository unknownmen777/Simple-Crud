﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(@"Enter The Number :");
            int num = Convert.ToInt32(Console.ReadLine());

            if (num % 2 == 0)
            {
                Console.WriteLine("{0} is Even number ", num);

            }
            else
            {
                Console.WriteLine("{0} is odd number ", num);
            }
            Console.ReadLine();
        }
    }
}
