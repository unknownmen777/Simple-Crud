﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp41
{

    class pet
    {
        public virtual void display()
        {
            Console.WriteLine("this is pet class ");
        }
    }

    class dog: pet 
    {
        public override void display()
        {
            //base.display();
            Console.WriteLine("this is dog class ");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            dog dog = new dog();
            dog.display();
            Console.ReadKey();

        }
    }
}
