﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter num1 : ");
            int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter num2 : ");
            int num2 = int.Parse(Console.ReadLine());

            if (num1 > num2)
            {
                Console.WriteLine("{0} is largest number.", num1);
            }
            else
            {

                Console.WriteLine("{0} is largest number", num2);
            }
            Console.ReadLine();
        }
    }
}
