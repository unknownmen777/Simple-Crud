﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class example
{
    private example() // restication cant create object  , only call by class name 
    {

    }
    public static void display() // only static constructor are used 
    {
        Console.WriteLine("this is private constructor ");
    }
}

namespace private_constructor
{
    internal class Program
    {
        static void Main(string[] args)
        {
          //  example obj = new example(); // error
            example.display();
            Console.ReadKey();
        }
    }
}
