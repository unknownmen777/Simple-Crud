﻿using System;

class Program
{
    static void Main()
    {
        // Initialize variables
        int count = 0;
        int number = 1;

        Console.WriteLine("The first 10 natural numbers divisible by both 7 and 13 are:");

        // Loop until we find 10 numbers divisible by both 7 and 13
        while (count < 10)
        {
            if (number % 7 == 0 && number % 13 == 0)
            {
                Console.WriteLine(number);
                count++;
            }
            number++;
        }
        Console.ReadLine();
    }
}
