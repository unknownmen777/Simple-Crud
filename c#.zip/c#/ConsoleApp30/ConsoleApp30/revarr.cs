﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp30
{
    internal class revarr
    {
        static void Main(string[] args)
        {
            int i, n;
            int[] arr = new int[10];
            Console.WriteLine("how many array input");
            n = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the element");

            for (i = 0; i < n; i++) {

                arr[i] = int.Parse(Console.ReadLine()); 
            }

            Console.WriteLine("the element");
            for (i = 0; i < n; i++)
            {
                Console.WriteLine(arr[i]);
            }
            Console.WriteLine("reverse element");

            for (i = n - 1;i >= 0; i--)
            {

            Console.WriteLine(arr[i]);
            }
       
            Console.ReadLine();

        }
    }
}
