﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sealed_method
{

    class a { 
    public virtual void man()
        {
            Console.WriteLine("This is class A");
        }
    }

    class b : a{
        public sealed override void man() // cannot override  because it is sealad
        {
            Console.WriteLine("This is class b");
        }
    }
    class c : b
    {
        public sealed override void man()
        {
            Console.WriteLine("This is class c");
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            c c = new c();  
            c.man();
            Console.ReadKey();
        }
    }
}
