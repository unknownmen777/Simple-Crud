﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double pi = Math.PI;
            Console.WriteLine("Enter the radious ");
            float r = float.Parse(Console.ReadLine());

            float aoc = (float)pi * r * r;

            Console.WriteLine("Area of circle are : {0} ", aoc);
        Console.ReadLine();
        }
    }
}
