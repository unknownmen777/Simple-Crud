﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp21
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter The Range Start ");
            int start = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter The Range End ");
            int end = Convert.ToInt32(Console.ReadLine());

            for (int i = start; i <= end; i++) {
                if (isprime(i))
                {
                    Console.WriteLine(i);
                }
            }
            Console.ReadLine();

        }
        public static bool isprime(int n) {
            if (n <= 1)
            {
                return false;
            }
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
