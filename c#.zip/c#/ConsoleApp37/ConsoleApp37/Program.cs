﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp37
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[,] arr1 = new int[50, 50];
            int[,] arr2 = new int[50, 50];
            int[,] arrsum = new int[50, 50];
            int i, j;

            Console.Write("Enter the array 1 element ");

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.Write("Element : {0}{1} = ", i, j);
                    arr1[i, j] = int.Parse(Console.ReadLine());
                }
            }

            Console.Write("Enter the array 2 element ");

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.Write("Element : {0}{1} = ", i, j);
                    arr2[i, j] = int.Parse(Console.ReadLine());
                }
            }

            Console.WriteLine("Display array 1 element\n ");

            for (i = 0; i < 3; i++)
            {
                Console.Write("\n");
                for (j = 0; j < 3; j++)
                {
                    Console.Write(" {0}\t", arr1[i,j]);
                }
            }

            Console.WriteLine("Display array 2 element\n ");
            for (i = 0; i < 3; i++)
            {
                Console.Write("\n");
                for (j = 0; j < 3; j++)
                {
                    Console.Write(" {0}\t", arr2[i, j]);
                }
            }
            // sum arr1 +arr2

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    arrsum[i, j] = arr1[i,j]+arr2[i,j];
                }
            }

            Console.WriteLine("Display Sum element\n ");

            for (i = 0; i < 3; i++)
            {
                Console.Write("\n");
                for (j = 0; j < 3; j++)
                {
                    Console.Write(" {0}\t", arrsum[i, j]);
                }
            }
            Console.ReadLine();

        }
    }
}
